from prey_predator.server import server

server.launch()
